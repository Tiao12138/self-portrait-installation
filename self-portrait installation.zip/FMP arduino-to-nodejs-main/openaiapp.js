// require('dotenv').config();
// console.log('API Key:', process.env.OPENAI_API_KEY);

const express = require('express');
const http = require('http');
const { Server, Socket } = require("socket.io");
const path = require('path'); // Make sure to import path

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
    transports: ['websocket', 'polling']  // Use WebSocket and fallback to polling
});

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(express.static(path.join(__dirname, 'public')));

const {SerialPort} = require('serialport');
const {ReadlineParser} = require('@serialport/parser-readline');

// import { port } from 'serialport'
const port = new SerialPort({ path: 'COM3', baudRate: 9600 })

const parser = port.pipe(new ReadlineParser({ delimiter: '\r\n' }));

const { OpenAI } = require('openai');

const openai = new OpenAI({
    apiKey: 'sk-proj-KJBMMz9Fh7tfMkHeLWCUT3BlbkFJ2Ju1S0YXyszwkFsfQCIy', // Ensure you've set this in your environment
});


let store = {
    lengthMode: 1,// 1， 2， 3
    // styleMode: 1,// 1, 2, 3
    filterMode: 1,
    userQuestion2Input: null
}

const getPrompt = () => {
    let prompt = `
You are an expert at generating a short description that acts as a textual portrait.
The portrait is based on the answer that a user has provided to a question about how they are feeling now.
`
    // switch (store.styleMode) {
    //     case 1:
    //         prompt += 'The text should be in the style of magical realism.'
    //     case 2:
    //         prompt += 'The '
    // } 
    switch (store.lengthMode) {
        case 1:
            prompt += 'The text should also be a barbara kruger style short slogan. very short and provoking, positive, give me only the slogan.';
        case 2:
            prompt += 'The text should be strictly more than 10 words and less than 30 words, poetic, and do not directly refer to any elements in user input.';
        case 3:
            prompt += 'The text should be very strictly from 30 to 60 words, story-like, artistic, and do not directly refer to any elements in user input.';
    } 
    return prompt
}

parser.on('data', async data => {
    const trimmedData = data.trim();
    //  console.log('Received data:', data);
    
    if (trimmedData === "length:1" && store.lengthMode !== 1) {
        store.lengthMode = 1
        console.log ('lengthMode = 1')
        await refreshPortrait()
    }
    if (trimmedData === "length:2" && store.lengthMode !== 2) {
        store.lengthMode = 2
        console.log ('lengthMode = 2')
        await refreshPortrait()
    }
    if (trimmedData === "length:3"&& store.lengthMode !== 3) {
        store.lengthMode = 3
        console.log ('lengthMode = 3')
        await refreshPortrait()
    
    } else if (trimmedData.startsWith("filter:")) {
        const filterMode = parseInt(trimmedData.split(':')[1]);
        if (store.filterMode !== filterMode) {
            store.filterMode = filterMode;
            const filterName = filterMode === 1 ? 'POSTERIZE' : filterMode === 2 ? 'GRAY' : 'NONE';
            io.emit('updateFilter', { filter: filterName });
        }
    } else if (trimmedData === "Button2 pressed") {
        console.log("Physical button2 was pressed. Regenerating response.");
        await refreshPortrait();
    } else if (trimmedData === "Submit") {
        console.log("Physical button was pressed. Triggering submit.");
        io.emit('defocus');
        //   userInput = store.userQuestion2Input
        // // == null ? getUserInput() : store.userQuestion2Input;
        //   await sendChatGPTResponse(getPrompt(), store.userQuestion2Input);
        // if (userInput) {
        //     await sendChatGPTResponse(getPrompt(), userInput);
        // }
    } else if (trimmedData === "Focus1"){
        io.emit('focus1');
        console.log("focus1 is pressed.");
    } else if (trimmedData === "Focus2"){
        io.emit('focus2');
        console.log("focus2 is pressed.");
    }else if (trimmedData === "Startover") {
        console.log("Startover command received. Redirecting to initial page.");
        io.emit('redirectToHome');
    }else if (trimmedData === "Freeze") {
        console.log("Freeze command received. Toggling freeze state.");
        io.emit('toggleFreeze');
    }else if (trimmedData === "requestprinterText2") {
        console.log("requestprinterText2 received.");
        sendprinterText2();
    }
       
});

async function sendChatGPTResponse(prompt, userInput) {
    const messages = [
        {role: "system", content: prompt },
        {role: "user", content: `The user answered the following: ${userInput.userInput}` },
    ]

    console.log("this is messages:" + userInput);

    let previousInput = store.userQuestion2Input;
    console.log("previous input:" + previousInput);
    console.log("user input:" + userInput);
    if (userInput != null && previousInput != userInput) store.userQuestion2Input = userInput;
    


    try {
        const response = await openai.chat.completions.create({
            model: "gpt-4o",
            messages: messages,
            max_tokens: 500
        });
        // console.log('response', response)
        // console.log('message', response.choices[0].message)
        io.emit('gptResponse', { mode: 'something', message: response.choices[0].message.content });
    } catch (error) {
        console.error('Error calling OpenAI API:', error);
        io.emit('apiError', 'Failed to process the request');
    }
}

async function refreshPortrait() {
    const prompt = getPrompt()
    const userInput = store.userQuestion2Input
    // console.log('this is store '+ store)
    if (userInput === null) {
        console.error('No user input, not refreshing yet')
        return
    }

    // const screenshot = get Screenshot()

    await sendChatGPTResponse(prompt, userInput)
}

io.on('connection', (socket) => {
    console.log('A user connected');

    socket.on('disconnect', () => {
        console.log('User disconnected');
    });
    
    socket.on('requestCurrentMode', async ({ userInput }) => {
        console.log('requestCurrentMode user input:', userInput)
        store.userQuestion2Input = userInput
        console.log("submit:" + store.userQuestion2Input)
        await refreshPortrait()
    });

    socket.on('setUserInput', (userInput) => {
        console.log("this is userInput:\n"+ userInput.userInput);
        store.userQuestion2Input = userInput;
        
        sendChatGPTResponse(getPrompt(), userInput);
        // if (userInput) {
        //     sendChatGPTResponse(getPrompt(), userInput);
        // }
    })

    // socket.emit("hello", "world");
});


parser.on('data', function(data) {
    if (data.trim() === "Button pressed") {
        console.log("Button was pressed. Emitting to clients.");
        io.emit('refreshPage', {}); // Emit the refreshPage event to clients
    }
});


app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'openaiapp.html'));
});

app.get('/response', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'response.html'));
});

app.post('/send1', (req, res) => {
    console.log("====================");
    console.log(req.body); 
    const { printerText1 } = req.body;
    console.log (printerText1);

    port.write(`PRINTER1:${printerText1}\n`, (err) => {
        if (err) {
            console.error('Failed to send to Printer 1:', err);
            return res.status(500).send('Failed to send to Printer 1');
        }
        console.log('Message sent to Printer 1');
    });

    res.status(200).send('Messages sent to both printers');
});

var printerText2;
// var printerText2 ;
app.post('/send2', (req, res) => {

    console.log("====================");
    console.log(req.body);
    const getprinterText2 = req.body;
    printerText2 = getprinterText2.printerText2;
    console.log ('pt2.1' , printerText2);
        // const { printerText2 } = req.body.printerText2;
      
    // port.write(`PRINTER2:${printerText2}`, (err) => {
    //     if (err) {
    //         console.error('Failed to send to Printer 2:', err);
    //         return res.status(500).send('Failed to send to Printer 2');
    //     }
    //     console.log('Message sent to Printer 2');
    // });

    res.status(200).send('Messages sent to both printers');
});

function sendprinterText2 (){
    console.log('pt2.2' + printerText2);
    // const { printerText2 } = req.body.printerText2;
    port.write(`PRINTER2:${printerText2}`, (err) => {
        if (err) {
            console.error('Failed to send to Printer 2:', err);
            return res.status(500).send('Failed to send to Printer 2');
        }
        console.log('Message sent to Printer 2');
    });
}


// function SendSecond(){

// }

const PORT = process.env.PORT || 8080;

server.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
